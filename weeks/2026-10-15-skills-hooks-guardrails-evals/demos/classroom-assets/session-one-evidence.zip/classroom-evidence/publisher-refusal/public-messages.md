I’ll inspect the configured source and target, then run the publisher’s read-only preparation checks. I’ll stop before publication and won’t alter the repository or its history.

Publication preparation failed. The publisher found the staged path `credentials.txt` in the index, flagged as a synthetic teaching marker. I did not print its contents.

No publication occurred, and I made no repository or history changes.
