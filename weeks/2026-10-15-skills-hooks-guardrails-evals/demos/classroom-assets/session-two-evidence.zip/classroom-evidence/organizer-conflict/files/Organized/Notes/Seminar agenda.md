# Seminar agenda
1. Agent workflows
2. Observable tool calls
3. Independent verification
