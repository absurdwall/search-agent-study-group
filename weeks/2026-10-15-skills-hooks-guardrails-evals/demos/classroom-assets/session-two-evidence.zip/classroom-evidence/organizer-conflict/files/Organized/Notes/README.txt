Existing team reference. Preserve this file unchanged.
