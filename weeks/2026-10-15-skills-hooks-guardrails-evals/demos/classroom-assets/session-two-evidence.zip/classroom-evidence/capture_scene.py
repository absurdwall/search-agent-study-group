from pathlib import Path
import json, shutil, sys, hashlib
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
PROJECT = Path('/Users/tingranwang/Documents/Codex/Projectless task folder/2026-10-15/organizer-desktop-feasibility')
STATE = Path('/private/var/folders/1l/xh7kf4ss1rqg3vxjr17q9_0w0000gn/T/ch5-desktop-implementation-wakn_7hu/state')
PUBLISHER = STATE.parent / 'publisher'
WORKER = '01a14608-fb39-74d1-9b42-fce527b10ce3'

def capture(scene, turn):
    out = ROOT / scene
    out.mkdir(exist_ok=True)
    if scene.startswith('organizer'):
        target = out / 'state'
        shutil.copytree(STATE, target, ignore=shutil.ignore_patterns('runs'), dirs_exist_ok=True)
        for name in ['Inbox', 'Organized']:
            shutil.copytree(PROJECT / name, out / 'files' / name, dirs_exist_ok=True)
    else:
        shutil.copytree(PUBLISHER, out / 'fixture', dirs_exist_ok=True)
    trace = next(Path('/Users/tingranwang/.codex/sessions/2026/10/16').glob('*' + WORKER + '*.jsonl'))
    identities, public, feedback = [], [], []
    active = None
    for line in trace.read_text().splitlines():
        d = json.loads(line)
        p = d.get('payload', {})
        if d['type'] == 'turn_context':
            active = p.get('turn_id')
            if active == turn:
                identities.append({k:p.get(k) for k in ['turn_id','model','effort','approval_policy','sandbox_policy']})
        if active != turn:
            continue
        if d['type'] == 'response_item' and p.get('type') == 'message' and p.get('role') in ['user','assistant']:
            public.append(p)
        if d['type'] == 'response_item' and p.get('type') in ['custom_tool_call_output','function_call_output']:
            content = str(p.get('output',''))
            if 'PreToolUse' in content or 'ready' in content or 'blocked' in content:
                feedback.append(p)
    (out/'identity.json').write_text(json.dumps({'worker':WORKER,'turn':turn,'captured_at':datetime.now(ZoneInfo('America/New_York')).isoformat(),'runtime':identities},indent=2))
    (out/'public-transcript.json').write_text(json.dumps(public,indent=2))
    (out/'runtime-feedback.json').write_text(json.dumps(feedback,indent=2))
    manifest = {str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name != 'manifest.json'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'scene':scene,'turn':turn,'path':str(out),'runtime':identities,'files':len(manifest),'feedback_records':len(feedback)},indent=2))

if __name__ == '__main__':
    capture(sys.argv[1],sys.argv[2])
