# Synthetic workshop
A disposable publication fixture.
