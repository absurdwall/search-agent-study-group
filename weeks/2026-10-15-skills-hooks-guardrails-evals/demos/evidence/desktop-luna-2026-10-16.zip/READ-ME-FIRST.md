# Chapter 5 two-chat Desktop rehearsal evidence

Read source/weeks/2026-10-15-skills-hooks-guardrails-evals/demos/INSTRUCTOR.md and evals/README.md.

Four fresh Desktop chats used the same clickable request and gpt-6-luna / max. Initial normal passed; initial conflict failed only its unresolved-path report. A narrow Skill-only clarification was followed by two fresh passing rechecks. The failed result is preserved.

All synthetic final files, backups, plans, service/hook logs, reports and grades are retained. runtime-identity.json extracts only model, effort and permission fields from runtime turn records. conversation.public.json retains public task items and omits reasoning and unrelated host-memory output. Original chats are retained. This is not a memory-isolated benchmark or a screenshot check.

Archived configs contain original machine paths for provenance. Provision fresh disposable paths to rerun elsewhere. Do not execute archived runtime configs as a portable setup. The previous CLI checkpoint is a separate retained bundle.
