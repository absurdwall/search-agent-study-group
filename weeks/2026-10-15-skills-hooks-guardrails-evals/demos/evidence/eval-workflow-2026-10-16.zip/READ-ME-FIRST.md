# Chapter 5 natural Skill invocation and Eval evidence

Start with source/weeks/2026-10-15-skills-hooks-guardrails-evals/demos/INSTRUCTOR.md and evals/README.md.

The two final CLI trials each use one identical natural English request. Source, native traces, hook/service logs, file results, byte backups, grader outputs, test log and metadata regression are included. The trace reviewer was Codex; automatic results retain human qualitative review as pending.

Stored runtime configs identify original machine paths for provenance. To rerun elsewhere, provision fresh disposable paths with lab.py; do not execute archived configs blindly. Prior accepted Desktop evidence is retained under source/.../demos/evidence/. No website changes or remote publication were made.
